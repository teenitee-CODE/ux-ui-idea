import React, { useState } from 'react';
import { IdeaTable } from './IdeaTable';
import { AddIdeaForm } from './AddIdeaForm';
import { SearchIcon, FilterIcon, RefreshCwIcon, DownloadIcon } from 'lucide-react';
import { mockData } from './mockData';
export const IdeaManagement = () => {
  const [selectedUser, setSelectedUser] = useState('');
  const [selectedTagTeam, setSelectedTagTeam] = useState('');
  const [selectedCreator, setSelectedCreator] = useState('');
  const [selectedGroup, setSelectedGroup] = useState('');
  const [perPage, setPerPage] = useState('10');
  const [keyword, setKeyword] = useState('');
  // Get unique tag teams and creators from data
  const uniqueTagTeams = [...new Set(mockData.map(item => item.tagTeam))].filter(Boolean);
  const uniqueCreators = [...new Set(mockData.map(item => item.userCreated))].filter(Boolean);
  const uniqueGroups = ['AI & Machine Learning', 'Healthcare Solutions', 'IoT Projects', 'Blockchain Apps', 'Cloud Services', 'Data Analytics'];
  return <div className="container mx-auto p-4">
      {/* Header Section */}
      <div className="bg-white rounded-lg shadow p-6 mb-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-gray-800">
            Idea Product List
          </h1>
        </div>
        {/* Stats Row */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-blue-50 rounded-lg p-4">
            <div className="text-sm text-blue-600">Total Ideas</div>
            <div className="text-2xl font-bold text-blue-700">247</div>
          </div>
          <div className="bg-green-50 rounded-lg p-4">
            <div className="text-sm text-green-600">Active Models</div>
            <div className="text-2xl font-bold text-green-700">3</div>
          </div>
          <div className="bg-purple-50 rounded-lg p-4">
            <div className="text-sm text-purple-600">Total AI Entries</div>
            <div className="text-2xl font-bold text-purple-700">1,458</div>
          </div>
          <div className="bg-orange-50 rounded-lg p-4">
            <div className="text-sm text-orange-600">Assigned Users</div>
            <div className="text-2xl font-bold text-orange-700">42</div>
          </div>
        </div>
        {/* Main Filters */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          {/* Search Box */}
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">
              Search
            </label>
            <div className="relative">
              <input type="text" className="w-full border border-gray-300 rounded-md px-3 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Search ideas, niches, or AI names..." value={keyword} onChange={e => setKeyword(e.target.value)} />
              <SearchIcon size={20} className="absolute right-3 top-2.5 text-gray-400" />
            </div>
          </div>
          {/* Group Filter */}
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">
              Group idea / niche / AI Model
            </label>
            <select className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" value={selectedGroup} onChange={e => setSelectedGroup(e.target.value)}>
              <option value="">All Groups</option>
              {uniqueGroups.map(group => <option key={group} value={group}>
                  {group}
                </option>)}
            </select>
          </div>
          {/* Tag Team Filter */}
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">
              Tag Team
            </label>
            <select className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" value={selectedTagTeam} onChange={e => setSelectedTagTeam(e.target.value)}>
              <option value="">All Tag Teams</option>
              {uniqueTagTeams.map(team => <option key={team} value={team}>
                  {team}
                </option>)}
            </select>
          </div>
          {/* User Assigned Filter */}
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">
              User Assigned
            </label>
            <select className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" value={selectedUser} onChange={e => setSelectedUser(e.target.value)}>
              <option value="">All Users</option>
              <option value="team_leaders">Team Leaders</option>
              <option value="researchers">Researchers</option>
              <option value="developers">Developers</option>
            </select>
          </div>
        </div>
        {/* Advanced Filters */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Created By Filter */}
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">
              Created By
            </label>
            <select className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" value={selectedCreator} onChange={e => setSelectedCreator(e.target.value)}>
              <option value="">All Creators</option>
              {uniqueCreators.map(creator => <option key={creator} value={creator}>
                  {creator}
                </option>)}
            </select>
          </div>
          {/* Date Range Filter */}
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">
              Date Range
            </label>
            <select className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="">All Time</option>
              <option value="today">Today</option>
              <option value="week">This Week</option>
              <option value="month">This Month</option>
              <option value="custom">Custom Range</option>
            </select>
          </div>
          {/* Status Filter */}
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">
              Status
            </label>
            <select className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="">All Status</option>
              <option value="active">Active</option>
              <option value="pending">Pending</option>
              <option value="completed">Completed</option>
            </select>
          </div>
          {/* AI Entries Count Filter */}
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">
              AI Entries Count
            </label>
            <select className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="">Any</option>
              <option value="1-5">1-5 entries</option>
              <option value="6-10">6-10 entries</option>
              <option value="11-20">11-20 entries</option>
            </select>
          </div>
        </div>
      </div>
      {/* Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <AddIdeaForm />
        </div>
        <div className="lg:col-span-2">
          <IdeaTable data={mockData} />
        </div>
      </div>
    </div>;
};