import React, { useState } from 'react';
import { MoreVerticalIcon, TrashIcon, ChevronDownIcon, ChevronUpIcon, ExternalLinkIcon, EyeIcon, PencilIcon, UsersIcon, ArchiveIcon, ShareIcon, UploadIcon, DownloadIcon } from 'lucide-react';
import { EditIdeaModal } from './EditIdeaModal';
import { Tooltip } from './Tooltip'; // Assume we have this component
// Sample data with correct number of entries and realistic examples
const sampleAIEntries = {
  GPT: [{
    nameAI: 'Pet Care Assistant',
    linkAI: 'https://chat.openai.com/g/pet-care-expert'
  }, {
    nameAI: 'Dog Training Expert',
    linkAI: 'https://chat.openai.com/g/dog-trainer-pro'
  }, {
    nameAI: 'Cat Behavior Specialist',
    linkAI: 'https://chat.openai.com/g/cat-whisperer'
  }, {
    nameAI: 'Veterinary Advisor',
    linkAI: 'https://chat.openai.com/g/vet-advisor'
  }, {
    nameAI: 'Pet Nutrition Guide',
    linkAI: 'https://chat.openai.com/g/pet-nutrition'
  }, {
    nameAI: 'Animal Health Monitor',
    linkAI: 'https://chat.openai.com/g/health-monitor'
  }, {
    nameAI: 'Pet Grooming Tips',
    linkAI: 'https://chat.openai.com/g/grooming-expert'
  }, {
    nameAI: 'Animal First Aid',
    linkAI: 'https://chat.openai.com/g/first-aid-pet'
  }, {
    nameAI: 'Pet Exercise Coach',
    linkAI: 'https://chat.openai.com/g/exercise-coach'
  }, {
    nameAI: 'Pet Mental Health',
    linkAI: 'https://chat.openai.com/g/mental-health'
  }, {
    nameAI: 'Pet Social Training',
    linkAI: 'https://chat.openai.com/g/social-trainer'
  }, {
    nameAI: 'Emergency Pet Care',
    linkAI: 'https://chat.openai.com/g/emergency-care'
  }],
  Gemini: [{
    nameAI: 'Animal Care Pro',
    linkAI: 'https://gemini.google.com/app/animal-care'
  }, {
    nameAI: 'Pet Diet Planner',
    linkAI: 'https://gemini.google.com/app/diet-plan'
  }, {
    nameAI: 'Training Assistant',
    linkAI: 'https://gemini.google.com/app/training'
  }, {
    nameAI: 'Health Tracker',
    linkAI: 'https://gemini.google.com/app/health'
  }, {
    nameAI: 'Behavior Analyst',
    linkAI: 'https://gemini.google.com/app/behavior'
  }, {
    nameAI: 'Exercise Guide',
    linkAI: 'https://gemini.google.com/app/exercise'
  }, {
    nameAI: 'Wellness Coach',
    linkAI: 'https://gemini.google.com/app/wellness'
  }, {
    nameAI: 'Care Schedule',
    linkAI: 'https://gemini.google.com/app/schedule'
  }],
  Perplexity: [{
    nameAI: 'Pet Expert System',
    linkAI: 'https://perplexity.ai/pet-expert'
  }, {
    nameAI: 'Animal Care Guide',
    linkAI: 'https://perplexity.ai/care-guide'
  }, {
    nameAI: 'Health Assistant',
    linkAI: 'https://perplexity.ai/health-assist'
  }, {
    nameAI: 'Training Helper',
    linkAI: 'https://perplexity.ai/training'
  }, {
    nameAI: 'Diet Advisor',
    linkAI: 'https://perplexity.ai/diet'
  }]
};
// Extended mock data with more items
const extendedMockData = [{
  id: 1,
  status: 'Active',
  idea: 'AI-Powered Pet Healthcare Platform',
  niche: ['Pet Health', 'Veterinary Care', 'Animal Wellness', 'Pet Insurance', 'Pet Tech'],
  nameModel: 'GPT',
  aiEntries: {
    GPT: sampleAIEntries.GPT.slice(0, 12),
    Gemini: sampleAIEntries.Gemini.slice(0, 8),
    Perplexity: sampleAIEntries.Perplexity.slice(0, 5)
  },
  userAssigned: ['john_doe_product_leader', 'jane_smith_researcher', 'alex_wilson_developer'],
  userCreated: 'eric_nguyen_admin',
  createdAt: '2024-01-15 09:30:00',
  updatedAt: '2024-01-16 14:20:00'
}, {
  id: 2,
  status: 'Pending',
  idea: 'Smart Home Automation Assistant',
  niche: ['Home Automation', 'IoT', 'Smart Living', 'Voice Control', 'Energy Management'],
  nameModel: 'Gemini',
  aiEntries: {
    GPT: sampleAIEntries.GPT.slice(0, 10),
    Gemini: sampleAIEntries.Gemini.slice(0, 6),
    Perplexity: sampleAIEntries.Perplexity.slice(0, 4)
  },
  userAssigned: ['sarah_tech_lead', 'mike_developer', 'lisa_designer', 'tom_researcher'],
  userCreated: 'product_manager',
  createdAt: '2024-01-14 15:45:00',
  updatedAt: '2024-01-15 11:30:00'
}
// Add 8 more items with similar structure but different data...
];
export const IdeaTable = ({
  data
}) => {
  const [expandedRows, setExpandedRows] = useState({});
  const [expandedModels, setExpandedModels] = useState({});
  const [selectedIdea, setSelectedIdea] = useState(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [activeActionId, setActiveActionId] = useState(null);
  const INITIAL_VISIBLE_ENTRIES = 3;
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [currentPage, setCurrentPage] = useState(1);
  // Calculate pagination
  const totalItems = data.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = Math.min(startIndex + itemsPerPage, totalItems);
  const currentItems = data.slice(startIndex, endIndex);
  const toggleRowExpansion = id => {
    setExpandedRows(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };
  const toggleModelExpansion = (id, modelName) => {
    const key = `${id}-${modelName}`;
    setExpandedModels(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };
  const handleEdit = idea => {
    setSelectedIdea(idea);
    setIsEditModalOpen(true);
  };
  const handleSave = updatedData => {
    console.log('Saving updated data:', updatedData);
    // Here you would typically update your data source
    setIsEditModalOpen(false);
    setSelectedIdea(null);
  };
  const formatDate = dateString => {
    if (!dateString) return '-';
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return '-';
      return new Intl.DateTimeFormat('en-US', {
        year: 'numeric',
        month: 'short',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
      }).format(date);
    } catch (e) {
      return '-';
    }
  };
  const getStatusColor = status => {
    switch (status.toLowerCase()) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'completed':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  const getTagTeamColor = tagTeam => {
    // Hash the tag team string to generate consistent colors
    const hash = tagTeam.split('').reduce((acc, char) => char.charCodeAt(0) + acc, 0);
    const hue = hash % 360;
    return `bg-[hsl(${hue},85%,95%)] text-[hsl(${hue},85%,35%)]`;
  };
  const renderTagTeams = (tagTeams: string) => {
    if (!tagTeams) return null;
    const teams = tagTeams.split(',').map(team => team.trim()).filter(Boolean);
    const displayCount = 3;
    const remainingCount = teams.length - displayCount;
    return <div className="flex flex-wrap gap-1.5 max-w-[250px]">
        {teams.slice(0, displayCount).map((team, index) => {
        const hash = team.split('').reduce((acc, char) => char.charCodeAt(0) + acc, 0);
        const hue = hash % 360;
        return <span key={index} className="inline-block px-2 py-1 rounded-full text-xs whitespace-nowrap" style={{
          backgroundColor: `hsl(${hue}, 85%, 95%)`,
          color: `hsl(${hue}, 85%, 35%)`
        }}>
              {team}
            </span>;
      })}
        {remainingCount > 0 && <Tooltip content={teams.slice(displayCount).join(', ')}>
            <span className="inline-block px-2 py-1 rounded-full text-xs bg-gray-100 text-gray-600 cursor-help whitespace-nowrap">
              +{remainingCount} more
            </span>
          </Tooltip>}
      </div>;
  };
  return <div className="bg-white rounded-lg shadow">
      {/* Table Header with Actions */}
      <div className="p-4 border-b">
        <div className="flex justify-between items-center mb-4">
          <div className="text-gray-600">Total: {totalItems} ideas</div>
          <div className="flex items-center gap-3">
            <button className="flex items-center px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600 transition-colors">
              <TrashIcon size={18} className="mr-2" />
              Delete Selected
            </button>
            <button className="flex items-center px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors">
              <UploadIcon size={18} className="mr-2" />
              Import
            </button>
            <button className="flex items-center px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 transition-colors">
              <DownloadIcon size={18} className="mr-2" />
              Export
            </button>
          </div>
        </div>
        {/* Pagination Controls */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <select className="border rounded-md px-3 py-1.5" value={itemsPerPage} onChange={e => {
            setItemsPerPage(Number(e.target.value));
            setCurrentPage(1); // Reset to first page when changing items per page
          }}>
              <option value={10}>10</option>
              <option value={25}>25</option>
              <option value={50}>50</option>
            </select>
            <span className="text-sm text-gray-600">items per page</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-600">
              Showing {startIndex + 1}-{endIndex} of {totalItems} items
            </span>
            <div className="flex items-center gap-1">
              <button className="px-3 py-1.5 border rounded-md hover:bg-gray-50 disabled:opacity-50" disabled={currentPage === 1} onClick={() => setCurrentPage(prev => prev - 1)}>
                Previous
              </button>
              {Array.from({
              length: totalPages
            }, (_, i) => i + 1).map(page => <button key={page} className={`px-3 py-1.5 rounded-md ${currentPage === page ? 'bg-blue-600 text-white' : 'border hover:bg-gray-50'}`} onClick={() => setCurrentPage(page)}>
                  {page}
                </button>)}
              <button className="px-3 py-1.5 border rounded-md hover:bg-gray-50 disabled:opacity-50" disabled={currentPage === totalPages} onClick={() => setCurrentPage(prev => prev + 1)}>
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* Table Content */}
      <div className="overflow-x-auto w-full">
        <table className="min-w-full">
          <thead>
            <tr className="bg-gray-100">
              <th className="w-20 px-4 py-3 text-left border-r border-gray-200">
                ID
              </th>
              <th className="w-12 px-4 py-3 text-left border-r border-gray-200">
                <input type="checkbox" className="rounded" />
              </th>
              <th className="w-64 px-4 py-3 text-left border-r border-gray-200">
                <div className="flex items-center gap-2">
                  IDEA
                  <button className="text-gray-400 hover:text-gray-600">
                    <ChevronDownIcon size={16} />
                  </button>
                </div>
              </th>
              <th className="w-64 px-4 py-3 text-left border-r border-gray-200">
                <div className="flex items-center gap-2">
                  NICHE
                  <button className="text-gray-400 hover:text-gray-600">
                    <ChevronDownIcon size={16} />
                  </button>
                </div>
              </th>
              <th className="w-32 px-4 py-3 text-left border-r border-gray-200">
                <div className="flex items-center gap-2">
                  TAG TEAM
                  <button className="text-gray-400 hover:text-gray-600">
                    <ChevronDownIcon size={16} />
                  </button>
                </div>
              </th>
              <th className="w-96 px-4 py-3 text-left border-r border-gray-200">
                <div className="flex items-center gap-2">
                  MODELS & AI ENTRIES
                  <button className="text-gray-400 hover:text-gray-600">
                    <ChevronDownIcon size={16} />
                  </button>
                </div>
              </th>
              <th className="w-64 px-4 py-3 text-left border-r border-gray-200">
                <div className="flex items-center gap-2">
                  USER ASSIGNED
                  <button className="text-gray-400 hover:text-gray-600">
                    <ChevronDownIcon size={16} />
                  </button>
                </div>
              </th>
              <th className="w-48 px-4 py-3 text-left border-r border-gray-200">
                CREATED BY
                <button className="text-gray-400 hover:text-gray-600">
                  <ChevronDownIcon size={16} />
                </button>
              </th>
              <th className="w-48 px-4 py-3 text-left border-r border-gray-200">
                GROUP
                <button className="text-gray-400 hover:text-gray-600">
                  <ChevronDownIcon size={16} />
                </button>
              </th>
              <th className="w-48 px-4 py-3 text-left border-r border-gray-200">
                CREATED DATE
                <button className="text-gray-400 hover:text-gray-600">
                  <ChevronDownIcon size={16} />
                </button>
              </th>
              <th className="w-48 px-4 py-3 text-left border-r border-gray-200">
                UPDATED DATE
                <button className="text-gray-400 hover:text-gray-600">
                  <ChevronDownIcon size={16} />
                </button>
              </th>
              <th className="w-32 px-4 py-3 text-center">ACTIONS</th>
            </tr>
          </thead>
          <tbody>
            {currentItems.map(item => <tr key={item.id} className="border-t border-gray-200 hover:bg-gray-50">
                <td className="px-4 py-4 border-r border-gray-200">
                  #{item.id.toString().padStart(3, '0')}
                </td>
                <td className="px-4 py-4 border-r border-gray-200">
                  <input type="checkbox" className="rounded" />
                </td>
                <td className="px-4 py-4 border-r border-gray-200">
                  <div className="font-medium text-gray-900">{item.idea}</div>
                </td>
                <td className="px-4 py-4 border-r border-gray-200">
                  <div className="flex flex-wrap gap-1 max-w-[250px]">
                    {item.niche.slice(0, 2).map((tag, index) => <span key={index} className="px-2 py-0.5 bg-blue-100 text-blue-700 text-xs rounded-md whitespace-nowrap">
                        {tag}
                      </span>)}
                    {item.niche.length > 2 && <Tooltip content={item.niche.slice(2).join(', ')}>
                        <span className="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs rounded-md cursor-help">
                          +{item.niche.length - 2} more
                        </span>
                      </Tooltip>}
                  </div>
                </td>
                <td className="px-4 py-4 border-r border-gray-200">
                  {item.tagTeam && renderTagTeams(item.tagTeam)}
                </td>
                <td className="px-4 py-4 border-r border-gray-200">
                  <div className="space-y-3 max-h-[200px] overflow-y-auto pr-2">
                    {/* GPT Section */}
                    <div className="border-l-4 border-blue-500 pl-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full">
                            GPT
                          </span>
                          <span className="text-sm text-gray-500">
                            {item.aiEntries?.GPT?.length || 0} AI Entries
                          </span>
                        </div>
                        <button onClick={() => toggleModelExpansion(item.id, 'GPT')}>
                          {expandedModels[`${item.id}-GPT`] ? <ChevronUpIcon size={20} /> : <ChevronDownIcon size={20} />}
                        </button>
                      </div>
                      {expandedModels[`${item.id}-GPT`] && <div className="mt-2 space-y-2">
                          {item.aiEntries?.GPT?.map((entry, index) => <div key={index} className="ml-2 text-sm">
                              <div className="font-medium">{entry.nameAI}</div>
                              <a href={entry.linkAI} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline flex items-center gap-1">
                                {entry.linkAI}
                                <ExternalLinkIcon size={12} />
                              </a>
                            </div>)}
                        </div>}
                    </div>
                    {/* Gemini Section */}
                    <div className="border-l-4 border-purple-500 pl-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="px-3 py-1 bg-purple-100 text-purple-800 rounded-full">
                            Gemini
                          </span>
                          <span className="text-sm text-gray-500">
                            {item.aiEntries?.Gemini?.length || 0} AI Entries
                          </span>
                        </div>
                        <button onClick={() => toggleModelExpansion(item.id, 'Gemini')}>
                          {expandedModels[`${item.id}-Gemini`] ? <ChevronUpIcon size={20} /> : <ChevronDownIcon size={20} />}
                        </button>
                      </div>
                      {/* Similar expanded content for Gemini */}
                    </div>
                    {/* Perplexity Section */}
                    <div className="border-l-4 border-green-500 pl-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full">
                            Perplexity
                          </span>
                          <span className="text-sm text-gray-500">
                            {item.aiEntries?.Perplexity?.length || 0} AI Entries
                          </span>
                        </div>
                        <button onClick={() => toggleModelExpansion(item.id, 'Perplexity')}>
                          {expandedModels[`${item.id}-Perplexity`] ? <ChevronUpIcon size={20} /> : <ChevronDownIcon size={20} />}
                        </button>
                      </div>
                      {/* Similar expanded content for Perplexity */}
                    </div>
                  </div>
                </td>
                <td className="px-4 py-4 border-r border-gray-200">
                  <div className="flex items-center gap-2">
                    <div className="flex -space-x-2">
                      {Array.isArray(item.userAssigned) && item.userAssigned.slice(0, 3).map((user, index) => <Tooltip key={index} content={user}>
                            <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 border-2 border-white flex items-center justify-center text-sm">
                              {user.charAt(0).toUpperCase()}
                            </div>
                          </Tooltip>)}
                    </div>
                    {item.userAssigned.length > 3 && <Tooltip content={item.userAssigned.slice(3).join(', ')}>
                        <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full cursor-help">
                          +{item.userAssigned.length - 3}
                        </span>
                      </Tooltip>}
                  </div>
                </td>
                <td className="px-4 py-4 border-r border-gray-200">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
                      {item.userCreated.charAt(0).toUpperCase()}
                    </div>
                    <span className="text-sm">{item.userCreated}</span>
                  </div>
                </td>
                <td className="px-4 py-4 border-r border-gray-200">
                  <div className="flex flex-wrap gap-1.5 max-w-[250px]">
                    {item.groups?.map((group, index) => {
                  const hash = group.split('').reduce((acc, char) => char.charCodeAt(0) + acc, 0);
                  const hue = hash % 360;
                  return <span key={index} className="inline-block px-2 py-1 rounded-full text-xs whitespace-nowrap" style={{
                    backgroundColor: `hsl(${hue}, 85%, 95%)`,
                    color: `hsl(${hue}, 85%, 35%)`
                  }}>
                          {group}
                        </span>;
                })}
                  </div>
                </td>
                <td className="px-4 py-4 text-sm">
                  {formatDate(item.createdAt)}
                </td>
                <td className="px-4 py-4 text-sm">
                  {formatDate(item.updatedAt)}
                </td>
                <td className="px-4 py-4">
                  <div className="flex items-center justify-center space-x-2">
                    <button className="p-1">
                      <EyeIcon size={18} className="text-blue-500" />
                    </button>
                    <button onClick={() => handleEdit(item)} className="p-1">
                      <PencilIcon size={18} className="text-green-500" />
                    </button>
                    <button className="p-1">
                      <TrashIcon size={18} className="text-red-500" />
                    </button>
                  </div>
                </td>
              </tr>)}
          </tbody>
        </table>
      </div>
      {/* Bottom Pagination */}
      <div className="p-4 border-t">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <select className="border rounded-md px-3 py-1.5" value={itemsPerPage} onChange={e => {
            setItemsPerPage(Number(e.target.value));
            setCurrentPage(1);
          }}>
              <option value={10}>10</option>
              <option value={25}>25</option>
              <option value={50}>50</option>
            </select>
            <span className="text-sm text-gray-600">items per page</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-600">
              Showing {startIndex + 1}-{endIndex} of {totalItems} items
            </span>
            <div className="flex items-center gap-1">
              <button className="px-3 py-1.5 border rounded-md hover:bg-gray-50 disabled:opacity-50" disabled={currentPage === 1} onClick={() => setCurrentPage(prev => prev - 1)}>
                Previous
              </button>
              {Array.from({
              length: totalPages
            }, (_, i) => i + 1).map(page => <button key={page} className={`px-3 py-1.5 rounded-md ${currentPage === page ? 'bg-blue-600 text-white' : 'border hover:bg-gray-50'}`} onClick={() => setCurrentPage(page)}>
                  {page}
                </button>)}
              <button className="px-3 py-1.5 border rounded-md hover:bg-gray-50 disabled:opacity-50" disabled={currentPage === totalPages} onClick={() => setCurrentPage(prev => prev + 1)}>
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* Remove duplicate pagination at bottom */}
      <EditIdeaModal isOpen={isEditModalOpen} onClose={() => setIsEditModalOpen(false)} data={selectedIdea} onSave={handleSave} />
    </div>;
};