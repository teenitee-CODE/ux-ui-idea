import React, { useState } from 'react';
import { PlusIcon, XIcon, ChevronDownIcon, ChevronUpIcon, TrashIcon, XCircleIcon, PlusCircleIcon, SearchIcon } from 'lucide-react';
export const AddIdeaForm = () => {
  const [idea, setIdea] = useState('');
  const [selectedUser, setSelectedUser] = useState('');
  const [selectedNiche, setSelectedNiche] = useState('');
  const [modelEntries, setModelEntries] = useState([{
    modelName: '',
    aiEntries: [{
      nameAI: '',
      linkAI: ''
    }]
  }]);
  const [selectedNiches, setSelectedNiches] = useState([]);
  const [nicheInput, setNicheInput] = useState('');
  const [showNicheDropdown, setShowNicheDropdown] = useState(false);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [userInput, setUserInput] = useState('');
  const [showUserDropdown, setShowUserDropdown] = useState(false);
  const [tagTeams, setTagTeams] = useState<string[]>([]);
  const [tagTeamInput, setTagTeamInput] = useState('');
  const [groupInput, setGroupInput] = useState('');
  const [groups, setGroups] = useState<string[]>([]);
  // Sample data
  const availableNiches = ['Healthcare Tech', 'Smart Home', 'E-commerce', 'Virtual Reality', 'Blockchain', 'Machine Learning', 'IoT', 'Customer Service', 'Digital Assets', 'Cloud Security'];
  const availableUsers = [{
    id: 1,
    name: 'nguyen manh cuong',
    role: 'product_leader'
  }, {
    id: 2,
    name: 'vuong lap phong',
    role: 'product_member'
  }, {
    id: 3,
    name: 'nguyen thi my',
    role: 'researcher'
  }, {
    id: 4,
    name: 'dinh thu thao',
    role: 'developer'
  }, {
    id: 5,
    name: 'ngo manh',
    role: 'designer'
  }, {
    id: 6,
    name: 'ngo trang',
    role: 'product_member'
  }, {
    id: 7,
    name: 'lap phong chan',
    role: 'researcher'
  }];
  // Filter functions
  const filteredNiches = availableNiches.filter(niche => niche.toLowerCase().includes(nicheInput.toLowerCase()) && !selectedNiches.includes(niche));
  const filteredUsers = availableUsers.filter(user => user.name.toLowerCase().includes(userInput.toLowerCase()) && !selectedUsers.map(u => u.id).includes(user.id));
  const handleAddModel = () => {
    setModelEntries([...modelEntries, {
      modelName: '',
      aiEntries: [{
        nameAI: '',
        linkAI: ''
      }]
    }]);
  };
  const handleRemoveModel = modelIndex => {
    const newModelEntries = [...modelEntries];
    newModelEntries.splice(modelIndex, 1);
    setModelEntries(newModelEntries);
  };
  const handleModelChange = (modelIndex, value) => {
    const newModelEntries = [...modelEntries];
    newModelEntries[modelIndex].modelName = value;
    setModelEntries(newModelEntries);
  };
  const handleAddAiEntry = modelIndex => {
    const newModelEntries = [...modelEntries];
    newModelEntries[modelIndex].aiEntries.push({
      nameAI: '',
      linkAI: ''
    });
    setModelEntries(newModelEntries);
  };
  const handleRemoveAiEntry = (modelIndex, aiIndex) => {
    const newModelEntries = [...modelEntries];
    newModelEntries[modelIndex].aiEntries.splice(aiIndex, 1);
    setModelEntries(newModelEntries);
  };
  const handleAiEntryChange = (modelIndex, aiIndex, field, value) => {
    const newModelEntries = [...modelEntries];
    newModelEntries[modelIndex].aiEntries[aiIndex][field] = value;
    setModelEntries(newModelEntries);
  };
  const handleAddTagTeam = () => {
    const newTeam = tagTeamInput.trim();
    if (!newTeam) return;
    if (tagTeams.includes(newTeam)) {
      alert('This team already exists!');
      return;
    }
    setTagTeams([...tagTeams, newTeam]);
    setTagTeamInput('');
  };
  const handleRemoveTagTeam = (teamToRemove: string) => {
    setTagTeams(tagTeams.filter(team => team !== teamToRemove));
  };
  const handleAddGroup = () => {
    const newGroup = groupInput.trim();
    if (!newGroup) return;
    if (groups.includes(newGroup)) {
      alert('This group already exists!');
      return;
    }
    setGroups([...groups, newGroup]);
    setGroupInput('');
  };
  const handleRemoveGroup = (groupToRemove: string) => {
    setGroups(groups.filter(group => group !== groupToRemove));
  };
  return <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-xl font-bold text-gray-800 mb-6">Thêm mới Idea</h2>
      <form className="space-y-6">
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-gray-900 pb-2 border-b">
            Thông tin cơ bản
          </h3>
          {/* Add Group Section - Place before Idea */}
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">
              Group idea / niche / AI Model
            </label>
            <div className="space-y-2">
              <div className="flex gap-2">
                <input type="text" className="flex-1 border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Enter group..." value={groupInput} onChange={e => setGroupInput(e.target.value)} onKeyPress={e => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleAddGroup();
                }
              }} />
                <button type="button" onClick={handleAddGroup} className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                  Add
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {groups.map((group, index) => {
                const hash = group.split('').reduce((acc, char) => char.charCodeAt(0) + acc, 0);
                const hue = hash % 360;
                const bgColor = `hsl(${hue}, 85%, 95%)`;
                const textColor = `hsl(${hue}, 85%, 35%)`;
                return <span key={index} className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-sm" style={{
                  backgroundColor: bgColor,
                  color: textColor
                }}>
                      {group}
                      <button onClick={() => handleRemoveGroup(group)} className="hover:opacity-75">
                        <XCircleIcon size={16} />
                      </button>
                    </span>;
              })}
              </div>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">
              Idea <span className="text-red-500">*</span>
            </label>
            <textarea className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 min-h-[100px]" placeholder="Enter your idea" value={idea} onChange={e => setIdea(e.target.value)} />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">
              Select Niche <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <div className="flex flex-wrap gap-2 p-2 border rounded-md bg-white min-h-[42px]">
                {selectedNiches.map((niche, index) => <span key={index} className="inline-flex items-center px-2 py-1 bg-blue-100 text-blue-700 rounded-md text-sm">
                    {niche}
                    <button onClick={() => setSelectedNiches(selectedNiches.filter(n => n !== niche))} className="ml-1 text-blue-600 hover:text-blue-800">
                      <XCircleIcon size={16} />
                    </button>
                  </span>)}
                <div className="relative flex-1 min-w-[200px]">
                  <input type="text" className="w-full border-0 focus:ring-0 p-1 text-sm" placeholder="Search and select niches..." value={nicheInput} onChange={e => {
                  setNicheInput(e.target.value);
                  setShowNicheDropdown(true);
                }} onFocus={() => setShowNicheDropdown(true)} />
                  <SearchIcon size={16} className="absolute right-2 top-2 text-gray-400" />
                </div>
              </div>
              {showNicheDropdown && filteredNiches.length > 0 && <div className="absolute z-10 w-full mt-1 bg-white border rounded-md shadow-lg max-h-60 overflow-auto">
                  {filteredNiches.map((niche, index) => <button key={index} className="w-full px-4 py-2 text-left text-sm hover:bg-gray-100 flex items-center" onClick={() => {
                setSelectedNiches([...selectedNiches, niche]);
                setNicheInput('');
                setShowNicheDropdown(false);
              }}>
                      <PlusCircleIcon size={16} className="mr-2 text-blue-500" />
                      {niche}
                    </button>)}
                </div>}
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">
              User Assigned
            </label>
            <div className="relative">
              <div className="flex flex-wrap gap-2 p-2 border rounded-md bg-white min-h-[42px]">
                {selectedUsers.map(user => <span key={user.id} className="inline-flex items-center gap-2 px-2 py-1 bg-gray-100 rounded-full text-sm">
                    <span className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 text-xs">
                      {user.name.charAt(0).toUpperCase()}
                    </span>
                    <span>{user.name}</span>
                    <button onClick={() => setSelectedUsers(selectedUsers.filter(u => u.id !== user.id))} className="text-gray-400 hover:text-gray-600">
                      <XCircleIcon size={16} />
                    </button>
                  </span>)}
                <div className="relative flex-1 min-w-[200px]">
                  <input type="text" className="w-full border-0 focus:ring-0 p-1 text-sm" placeholder="Search and assign users..." value={userInput} onChange={e => {
                  setUserInput(e.target.value);
                  setShowUserDropdown(true);
                }} onFocus={() => setShowUserDropdown(true)} />
                  <SearchIcon size={16} className="absolute right-2 top-2 text-gray-400" />
                </div>
              </div>
              {showUserDropdown && filteredUsers.length > 0 && <div className="absolute z-10 w-full mt-1 bg-white border rounded-md shadow-lg max-h-60 overflow-auto">
                  {filteredUsers.map(user => <button key={user.id} className="w-full px-4 py-2 text-left text-sm hover:bg-gray-100 flex items-center" onClick={() => {
                setSelectedUsers([...selectedUsers, user]);
                setUserInput('');
                setShowUserDropdown(false);
              }}>
                      <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 text-xs mr-2">
                        {user.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <div>{user.name}</div>
                        <div className="text-xs text-gray-500">{user.role}</div>
                      </div>
                    </button>)}
                </div>}
            </div>
          </div>
          {/* Tag Teams section */}
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">
              Tag Teams
            </label>
            <div className="space-y-2">
              <div className="flex gap-2">
                <input type="text" className="flex-1 border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Enter tag team..." value={tagTeamInput} onChange={e => setTagTeamInput(e.target.value)} onKeyPress={e => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleAddTagTeam();
                }
              }} />
                <button type="button" onClick={handleAddTagTeam} className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                  Add
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {tagTeams.map((team, index) => {
                // Generate consistent color based on team name
                const hash = team.split('').reduce((acc, char) => char.charCodeAt(0) + acc, 0);
                const hue = hash % 360;
                const bgColor = `hsl(${hue}, 85%, 95%)`;
                const textColor = `hsl(${hue}, 85%, 35%)`;
                return <span key={index} className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-sm" style={{
                  backgroundColor: bgColor,
                  color: textColor
                }}>
                      {team}
                      <button onClick={() => handleRemoveTagTeam(team)} className="hover:opacity-75">
                        <XCircleIcon size={16} />
                      </button>
                    </span>;
              })}
              </div>
            </div>
          </div>
        </div>
        {/* Models Section */}
        <div className="space-y-4">
          <div className="flex justify-between items-center border-b pb-2">
            <h3 className="text-lg font-medium text-gray-900">
              Models & AI Entries
            </h3>
            <button type="button" onClick={handleAddModel} className="px-3 py-1 text-sm bg-green-600 text-white rounded-md hover:bg-green-700 flex items-center">
              <PlusIcon size={16} className="mr-1" />
              Add New Model
            </button>
          </div>
          <div className="space-y-6">
            {modelEntries.map((model, modelIndex) => <div key={modelIndex} className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                {/* Model Selection Header */}
                <div className="flex justify-between items-center mb-4">
                  <div className="flex-1 mr-4">
                    <label className="block text-sm font-medium text-gray-600 mb-1">
                      Select Model <span className="text-red-500">*</span>
                    </label>
                    <select className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" value={model.modelName} onChange={e => handleModelChange(modelIndex, e.target.value)}>
                      <option value="">Select Model</option>
                      <option value="GPT">GPT</option>
                      <option value="Gemini">Gemini</option>
                      <option value="Perplexity">Perplexity</option>
                    </select>
                  </div>
                  {modelIndex > 0 && <button type="button" onClick={() => handleRemoveModel(modelIndex)} className="text-red-500 hover:text-red-700">
                      <XIcon size={20} />
                    </button>}
                </div>
                {/* AI Entries Section */}
                <div className="bg-white rounded-lg p-4">
                  <div className="flex justify-between items-center mb-3">
                    <div className="text-sm text-gray-600">
                      AI Entries ({model.aiEntries.length}/20)
                    </div>
                    {model.aiEntries.length < 20 && <button type="button" onClick={() => handleAddAiEntry(modelIndex)} className="px-2 py-1 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center">
                        <PlusIcon size={14} className="mr-1" />
                        Add AI Entry
                      </button>}
                  </div>
                  <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2">
                    {model.aiEntries.map((entry, aiIndex) => <div key={aiIndex} className="relative border border-gray-100 rounded-lg p-3 bg-gray-50">
                        {/* Changed number display to inline with labels */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          <div>
                            <label className="flex items-center text-xs font-medium text-gray-600 mb-1">
                              <span className="w-5 h-5 bg-blue-500 text-white rounded-full flex items-center justify-center text-xs mr-2">
                                {aiIndex + 1}
                              </span>
                              Name AI
                            </label>
                            <input type="text" className="w-full border border-gray-300 rounded-md px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder={`Enter AI Name for ${model.modelName || 'selected model'}`} value={entry.nameAI} onChange={e => handleAiEntryChange(modelIndex, aiIndex, 'nameAI', e.target.value)} />
                          </div>
                          <div>
                            <label className="flex items-center text-xs font-medium text-gray-600 mb-1">
                              <span className="w-5 h-5 bg-blue-500 text-white rounded-full flex items-center justify-center text-xs mr-2">
                                {aiIndex + 1}
                              </span>
                              Link AI
                            </label>
                            <div className="relative">
                              <input type="url" className="w-full border border-gray-300 rounded-md px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="https://example.com" value={entry.linkAI} onChange={e => handleAiEntryChange(modelIndex, aiIndex, 'linkAI', e.target.value)} />
                              {aiIndex > 0 && <button type="button" onClick={() => handleRemoveAiEntry(modelIndex, aiIndex)} className="absolute right-2 top-1/2 -translate-y-1/2 text-red-500 hover:text-red-700">
                                  <TrashIcon size={14} />
                                </button>}
                            </div>
                          </div>
                        </div>
                      </div>)}
                  </div>
                </div>
              </div>)}
          </div>
        </div>
        <div className="flex space-x-3 pt-4 border-t">
          <button type="submit" className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500">
            Submit
          </button>
          <button type="button" className="px-6 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-500">
            Reset
          </button>
        </div>
      </form>
    </div>;
};