// Generate 30 random ideas with all required data
export const generateMockData = () => {
  const ideas = ["AI-Powered Healthcare Platform", "Smart Home Automation System", "E-commerce Analytics Dashboard", "Virtual Reality Training Platform", "Blockchain Payment Solution", "Machine Learning Image Recognition", "IoT Device Management System", "Automated Customer Support Bot", "Digital Asset Management Platform", "Cloud Security Solution"
  // ... add 20 more ideas
  ];
  const niches = ["Healthcare Tech", "Smart Home", "E-commerce", "Virtual Reality", "Blockchain", "Machine Learning", "IoT", "Customer Service", "Digital Assets", "Cloud Security"
  // ... add 50 more niches
  ];
  const creators = ["admin_user", "nguyen manh cuong", "vuong lap phong", "nguyen thi my"];
  const userPool = ["nguyen manh cuong", "vuong lap phong", "nguyen thi my", "dinh thu thao", "ngo manh", "ngo trang", "lap phong chan"];
  const statuses = ["Active", "Pending", "Completed"];
  // Generate random AI entries
  const generateAIEntries = (min, max) => {
    const count = Math.floor(Math.random() * (max - min + 1)) + min;
    return Array(count).fill(null).map((_, i) => ({
      nameAI: `AI Assistant ${i + 1}`,
      linkAI: `https://ai-platform.com/assistant-${i + 1}`
    }));
  };
  // Add tag teams to mock data
  const tagTeams = ["Team Alpha, Team Beta, Team Gamma, Research Squad, Dev Ninjas", "AI Masters, Dev Team, QA Squad, UX Team, Product Team", "Backend Squad, Frontend Team, Mobile Team, DevOps Team", "Design Team, Marketing Squad, Sales Team, Support Team", "Core Team, Innovation Squad, R&D Team, Architecture Team", "Team Alpha, Research Squad, Dev Ninjas, AI Masters"];
  // Add groups to mock data
  const groups = [["AI & Machine Learning", "Healthcare Solutions"], ["IoT Projects", "Data Analytics"], ["Blockchain Apps", "Cloud Services"], ["Healthcare Solutions", "Data Analytics"], ["AI & Machine Learning", "Cloud Services"], ["IoT Projects", "Blockchain Apps"]];
  // Generate 30 records
  return Array(30).fill(null).map((_, index) => ({
    id: index + 1,
    status: statuses[Math.floor(Math.random() * statuses.length)],
    idea: ideas[index % ideas.length],
    niche: Array(Math.floor(Math.random() * 3) + 2).fill(null).map(() => niches[Math.floor(Math.random() * niches.length)]),
    userCreated: creators[Math.floor(Math.random() * creators.length)],
    createdAt: "2025-05-19T" + String(Math.floor(Math.random() * 24)).padStart(2, '0') + ":00:00",
    updatedAt: new Date().toISOString(),
    aiEntries: {
      GPT: generateAIEntries(5, 20),
      Gemini: generateAIEntries(5, 20),
      Perplexity: generateAIEntries(5, 20)
    },
    userAssigned: Array(Math.floor(Math.random() * 4) + 1).fill(null).map(() => userPool[Math.floor(Math.random() * userPool.length)]),
    tagTeam: tagTeams[Math.floor(Math.random() * tagTeams.length)],
    groups: groups[Math.floor(Math.random() * groups.length)]
  }));
};
export const mockData = generateMockData();